package com.amos.spring.dschange;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.amos.spring.util.DataSourceKeyHolder;
import com.atomikos.jdbc.AtomikosDataSourceBean;

/**
 * User:Amos.zhou
 * Date: 14-3-14
 * Time: 下午5:59
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:applicationContext.xml")
//@ChooseDataSource("ds_1")
public class TestChangeDs {
	private final String configLocation = "classpath:com/amos/spring/dschange/mapper/ShopMapper.xml";
	private final String propPath = "src/test/resources/jdbc.properties";
	private final String driver = "com.mysql.jdbc.jdbc2.optional.MysqlXADataSource";
	
	@Autowired
	private ShopService shopService;
	@Autowired
	private Properties jdbcContext;
	@Autowired
	private ApplicationContext ctx;
	@Autowired
	private HashMap<String,Object> dataSourceMap;
	@Autowired
	private HashMap<String,Object> sqlSessionFactoryMap;

	@Test
	//@Rollback(false)
	// @ChooseDataSource("ds_1")
	public void testFindAllShop(){
		System.out.println("############################start############################");
		try{
			System.out.println("--------------------video_rest--------------------");
			List<Map<String, Object>> shopList1 = shopService.findAllShop();
			System.out.println(shopList1);
			System.out.println("--------------------game10--------------------");
			shopList1 = shopService.findAllShop4();
			System.out.println(shopList1);
			System.out.println("--------------------baijiale2--------------------");
			shopList1 = shopService.findAllShop2();
			System.out.println(shopList1);
			System.out.println("--------------------baijiale--------------------");
			shopList1 = shopService.findAllShop3();
			System.out.println(shopList1);
		}catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("############################end############################");
	}
	//@Test
	// @ChooseDataSource("ds_2")
	public void fromTestDB(){
		List<Map<String, Object>> shopList = shopService.findAllShop2();

		System.out.println(shopList);
		System.out.println("$$$$$$");
	}

	//@Test
	public void testJTA(){
		shopService.updateJta();
		System.out.println("SUCCESS JTA");
	}

	// @Test
	public void testJTAFail(){
		shopService.updateJtaFail();
		System.out.println("Fail JTA");
	}

	//@Test
	public void testContext(){
		try{
			InputStream in = new BufferedInputStream(new FileInputStream(propPath));
			jdbcContext.load(in);
			System.out.println(jdbcContext.getProperty("game10.url"));
		}catch (Exception e) {
			System.out.println(e);
		}
	}

	//@Test
	public void testResource(){
		try{
			Resource mapperResource = ctx.getResource(configLocation);
			System.out.println(mapperResource.contentLength());
			System.out.println("fileName:"+mapperResource.exists());
			System.out.println(mapperResource.getFile().exists());
		}catch (Exception e) {
			System.out.println(e);
		}
	}

	@Test
	public void testCreateDataSources(){
		String resultDS = "baijiale2";
		try {
			System.out.println("--------------------video_rest--------------------");
			List<Map<String, Object>> shopList1 = shopService.findAllShop();
			System.out.println(shopList1);
			
			System.out.println("--------------------baijiale2--------------------");
			//System.out.println(dataSourceMap);
			//System.out.println(sqlSessionFactoryMap);
			if(!dataSourceMap.containsKey(resultDS)){
				InputStream in = new BufferedInputStream(new FileInputStream(propPath));
				jdbcContext.load(in);
				//准备jdbc连接信息
				Properties xaProperties = new Properties();
				xaProperties.put("useUnicode", true);
				xaProperties.put("characterEncoding", "utf-8");
				xaProperties.put("url", jdbcContext.getProperty(resultDS+".url"));
				xaProperties.put("user", jdbcContext.getProperty(resultDS+".user"));
				xaProperties.put("password", jdbcContext.getProperty(resultDS+".password"));

				//加载数据源
				AtomikosDataSourceBean dataSource = new AtomikosDataSourceBean();
				dataSource.setPoolSize(10);
				dataSource.setMinPoolSize(10);
				dataSource.setMaxPoolSize(30);
				dataSource.setBorrowConnectionTimeout(60);
				dataSource.setReapTimeout(20);
				dataSource.setMaxIdleTime(60);
				dataSource.setMaintenanceInterval(60);
				dataSource.setLoginTimeout(60);
				dataSource.setTestQuery("select 1");
				dataSource.setUniqueResourceName("mysql/"+resultDS);
				dataSource.setXaDataSourceClassName(driver);
				dataSource.setXaProperties(xaProperties);
				dataSource.init();
				dataSourceMap.put(resultDS, dataSource);

				//创建sqlSeccionFactory
				SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
				factory.setDataSource(dataSource);
				//factory.setTypeAliasesPackage("com.amos.spring.dschange.bean");
				//factory.setConfigLocation(ctx.getResource(configLocation));
				factory.setMapperLocations(ctx.getResources(configLocation));
				sqlSessionFactoryMap.put(resultDS, factory.getObject());
			}
			DataSourceKeyHolder.setDataSourceKey(resultDS);
			//System.out.println(dataSourceMap);
			//System.out.println(sqlSessionFactoryMap);
			shopList1 = shopService.findAllShop2();
			System.out.println(shopList1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
