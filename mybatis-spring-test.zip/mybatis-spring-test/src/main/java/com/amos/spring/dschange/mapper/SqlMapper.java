package com.amos.spring.dschange.mapper;

/**
 * TODO: 增加描述
 * 
 * @author Administrator
 * @date 2015年9月23日 上午10:14:46
 * @version 0.1.0 
 * @copyright stnts.com 
 */
public interface SqlMapper {

}
