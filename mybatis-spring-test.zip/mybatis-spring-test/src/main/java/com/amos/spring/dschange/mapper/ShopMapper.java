package com.amos.spring.dschange.mapper;

import java.util.List;
import java.util.Map;

/**
 * User: Baron.Zhang
 * Date: 14-1-7
 * Time: 上午9:31
 */
public interface ShopMapper extends SqlMapper {

    public List<Map<String, Object>> findAllShop();
    
    public List<Map<String, Object>> findAllShop2();
    
    public List<Map<String, Object>> findAllShop3();
    
    public List<Map<String, Object>> findAllShop4();
    
    public void updateShop();
    
    public void updateShop2();
    
    public void updateShopFail();
    
    

}
