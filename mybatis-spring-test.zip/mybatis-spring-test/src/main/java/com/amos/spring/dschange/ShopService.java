package com.amos.spring.dschange;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amos.spring.annotation.ChooseDataSource;
import com.amos.spring.dschange.mapper.ShopMapper;

/**
 * User: Baron.Zhang
 * Date: 14-1-7
 * Time: 下午1:29
 */
@Service
public class ShopService {

//    @Resource
    @Autowired
    private ShopMapper shopMapper;

    @ChooseDataSource("video_rest")
    public List<Map<String, Object>> findAllShop() {
        return shopMapper.findAllShop();
    }
    
    @ChooseDataSource("baijiale2")
    public List<Map<String, Object>> findAllShop2() {
        return shopMapper.findAllShop2();
    }
    
    @ChooseDataSource("baijiale")
    public List<Map<String, Object>> findAllShop3() {
        return shopMapper.findAllShop3();
    }
    
    @ChooseDataSource("game10")
    public List<Map<String, Object>> findAllShop4() {
        return shopMapper.findAllShop4();
    }
    
    @ChooseDataSource("ds_1")
    public void updateShop(){
    	shopMapper.updateShop();
    }
    
    @ChooseDataSource("ds_2")
    public void updateShop2(){
    	shopMapper.updateShop2();
    }
    
    @ChooseDataSource("ds_2")
    public void updateShopFail(){
    	shopMapper.updateShopFail();
    }
    
    @Transactional
    public void updateJta(){
    	updateShop();
    	updateShop2();
    }
    
    @Transactional
    public void updateJtaFail(){
    	updateShop();
    	updateShopFail();
    }
}
